CS 330 Module Six 6-2 Assignment - Lighting

Based on the clean 6-2_Assignment template.
Two point lights: neutral white at (-4,8,6) and blue at (6,5,-3).
Five original white objects and plane are preserved.
Lighting is enabled only after both lights and a white surface material are set.

BUILD/RUN
Place 6-2_Assignment in the original CS330Content/Projects folder, alongside
CS330Content/Utilities, CS330Content/Libraries, and CS330Content/3DShapes.
Open 6-2_Assignment.sln in Visual Studio, choose Debug | Win32, then Rebuild Solution.
Run using Local Windows Debugger (F5). The working directory is set to $(ProjectDir),
so local shaders/vertexShader.glsl and shaders/fragmentShader.glsl resolve.

IMPORTANT: No updated EXE is included. Windows compilation and visual rendering
have not been tested in this environment. Rebuild and include the resulting EXE
in your final submission ZIP.

AI acknowledgement: ChatGPT assisted with implementing and commenting the lighting setup.
