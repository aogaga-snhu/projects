// CS 330 Module Eight: interactive 2D brick-and-ball collision scene.
// AI use acknowledgment: ChatGPT assisted with implementation and code organization.
#define _USE_MATH_DEFINES
#include <GLFW/glfw3.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <vector>

struct Vec2 {
    float x, y;
    Vec2(float a=0, float b=0) : x(a), y(b) {}
    Vec2 operator+(Vec2 v) const { return Vec2(x+v.x,y+v.y); }
    Vec2 operator-(Vec2 v) const { return Vec2(x-v.x,y-v.y); }
    Vec2 operator*(float s) const { return Vec2(x*s,y*s); }
    Vec2 operator/(float s) const { return Vec2(x/s,y/s); }
};
static float dot(Vec2 a,Vec2 b) { return a.x*b.x+a.y*b.y; }
static float length(Vec2 v) { return std::sqrt(dot(v,v)); }
static Vec2 normalized(Vec2 v) { float n=length(v); return n>0.00001f ? v/n : Vec2(1,0); }
static float clampf(float a,float lo,float hi) { return std::max(lo,std::min(hi,a)); }
static float random01() { return static_cast<float>(std::rand())/RAND_MAX; }

struct Color { float r,g,b; Color(float a=1,float c=1,float d=1):r(a),g(c),b(d){} };
struct Brick {
    Vec2 center, half;
    Color color;
    int hits; // 1: break on hit, 2: change color first and break on next hit
    bool active;
    Brick(Vec2 p,Vec2 h,Color c,int hp):center(p),half(h),color(c),hits(hp),active(true){}
    void draw() const {
        if(!active) return;
        glColor3f(color.r,color.g,color.b);
        glBegin(GL_QUADS);
        glVertex2f(center.x-half.x,center.y-half.y);
        glVertex2f(center.x+half.x,center.y-half.y);
        glVertex2f(center.x+half.x,center.y+half.y);
        glVertex2f(center.x-half.x,center.y+half.y);
        glEnd();
        // A subtle inset highlight makes each brick readable.
        glColor3f(std::min(1.f,color.r+.18f),std::min(1.f,color.g+.18f),std::min(1.f,color.b+.18f));
        glBegin(GL_LINES);
        glVertex2f(center.x-half.x+.01f,center.y+half.y-.01f);
        glVertex2f(center.x+half.x-.01f,center.y+half.y-.01f);
        glEnd();
    }
};
struct Ball {
    Vec2 pos, vel;
    float radius;
    Color color;
    Ball(Vec2 p,Vec2 v,float r,Color c):pos(p),vel(v),radius(r),color(c){}
    void draw() const {
        glColor3f(color.r,color.g,color.b);
        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(pos.x,pos.y);
        const float pi=3.14159265358979323846f;
        for(int i=0;i<=40;++i) {
            float t=2.f*pi*i/40.f;
            glVertex2f(pos.x+radius*std::cos(t),pos.y+radius*std::sin(t));
        }
        glEnd();
    }
};
static std::vector<Brick> bricks;
static std::vector<Ball> balls;
static bool previousSpace=false, previousR=false;
static const float boundary=.97f;

static void setupBricks() {
    bricks.clear();
    // Staggered, colorful rows: varied brick sizes and two durability levels.
    const Color palette[]={
        Color(.95f,.30f,.35f), Color(1.f,.65f,.22f),
        Color(.38f,.82f,.64f), Color(.32f,.62f,.96f)
    };
    for(int row=0;row<4;++row) {
        const int count=(row%2==0)?7:6;
        const float width=(row%2==0)?.23f:.26f;
        const float spacing=.025f;
        const float span=count*width+(count-1)*spacing;
        const float start=-span/2.f+width/2.f;
        for(int col=0;col<count;++col) {
            float x=start+col*(width+spacing);
            float y=.69f-row*.17f;
            int hp=((row+col)%4==0)?2:1;
            bricks.push_back(Brick(Vec2(x,y),Vec2(width*.5f,.065f),
                                   palette[row],hp));
        }
    }
}
static void spawnBall() {
    if(balls.size()>=8) return;
    float angle=.45f+random01()*2.25f;
    float speed=.58f+random01()*.20f;
    balls.push_back(Ball(Vec2((random01()-.5f)*.3f,-.62f),
        Vec2(std::cos(angle)*speed,std::sin(angle)*speed),.045f,
        Color(.6f+random01()*.4f,.6f+random01()*.4f,.6f+random01()*.4f)));
}
static void input(GLFWwindow* window) {
    if(glfwGetKey(window,GLFW_KEY_ESCAPE)==GLFW_PRESS) glfwSetWindowShouldClose(window,GL_TRUE);
    bool space=glfwGetKey(window,GLFW_KEY_SPACE)==GLFW_PRESS;
    if(space&&!previousSpace) spawnBall(); // edge-trigger: one ball per press
    previousSpace=space;
    bool reset=glfwGetKey(window,GLFW_KEY_R)==GLFW_PRESS;
    if(reset&&!previousR) { setupBricks(); balls.clear(); spawnBall(); spawnBall(); }
    previousR=reset;
}
static void collideWalls(Ball& b) {
    if(b.pos.x-b.radius < -boundary) { b.pos.x=-boundary+b.radius; b.vel.x=std::abs(b.vel.x); }
    if(b.pos.x+b.radius > boundary) { b.pos.x=boundary-b.radius; b.vel.x=-std::abs(b.vel.x); }
    if(b.pos.y-b.radius < -boundary) { b.pos.y=-boundary+b.radius; b.vel.y=std::abs(b.vel.y); }
    if(b.pos.y+b.radius > boundary) { b.pos.y=boundary-b.radius; b.vel.y=-std::abs(b.vel.y); }
}
static void collideBrick(Ball& ball,Brick& brick) {
    if(!brick.active) return;
    // Closest point on axis-aligned rectangle to circle center.
    Vec2 closest(clampf(ball.pos.x,brick.center.x-brick.half.x,brick.center.x+brick.half.x),
                 clampf(ball.pos.y,brick.center.y-brick.half.y,brick.center.y+brick.half.y));
    Vec2 delta=ball.pos-closest;
    float d2=dot(delta,delta);
    if(d2>=ball.radius*ball.radius) return;
    Vec2 normal;
    float distance=std::sqrt(d2);
    float penetration;
    if(distance>0.00001f) {
        normal=delta/distance;
        penetration=ball.radius-distance;
    } else {
        // Circle center inside brick: choose the nearest exit face.
        float dx=brick.half.x-std::abs(ball.pos.x-brick.center.x);
        float dy=brick.half.y-std::abs(ball.pos.y-brick.center.y);
        if(dx<dy) { normal=Vec2(ball.pos.x<brick.center.x?-1.f:1.f,0); penetration=ball.radius+dx; }
        else { normal=Vec2(0,ball.pos.y<brick.center.y?-1.f:1.f); penetration=ball.radius+dy; }
    }
    ball.pos=ball.pos+normal*(penetration+.0001f);
    if(dot(ball.vel,normal)<0) ball.vel=ball.vel-normal*(2.f*dot(ball.vel,normal));
    --brick.hits;
    if(brick.hits<=0) brick.active=false;
    else {
        brick.color=Color(std::min(1.f,brick.color.r+.25f),
                          std::min(1.f,brick.color.g+.25f),
                          std::min(1.f,brick.color.b+.25f));
    }
    ball.color=Color(.5f+random01()*.5f,.5f+random01()*.5f,.5f+random01()*.5f);
}
static void collideBalls(Ball& a,Ball& b) {
    Vec2 difference=b.pos-a.pos;
    float distance=length(difference);
    float target=a.radius+b.radius;
    if(distance>=target) return;
    Vec2 n=distance>.00001f?difference/distance:Vec2(1,0);
    // Separate overlapping equal-mass circles, then exchange normal velocities.
    float overlap=target-distance+.0001f;
    a.pos=a.pos-n*(overlap*.5f);
    b.pos=b.pos+n*(overlap*.5f);
    float relative=dot(b.vel-a.vel,n);
    if(relative<0) {
        a.vel=a.vel+n*relative;
        b.vel=b.vel-n*relative;
        a.color=Color(1.f,.86f,.35f);
        b.color=Color(.35f,1.f,.92f);
    }
}
static void step(float dt) {
    for(size_t i=0;i<balls.size();++i) {
        Ball& ball=balls[i];
        ball.pos=ball.pos+ball.vel*dt;
        collideWalls(ball);
        for(size_t j=0;j<bricks.size();++j) collideBrick(ball,bricks[j]);
    }
    for(size_t i=0;i<balls.size();++i)
        for(size_t j=i+1;j<balls.size();++j) collideBalls(balls[i],balls[j]);
}
int main() {
    std::srand(static_cast<unsigned int>(std::time(NULL)));
    if(!glfwInit()) return EXIT_FAILURE;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,0);
    GLFWwindow* window=glfwCreateWindow(760,760,
        "CS 330 Module Eight | Brick Collision Animation",NULL,NULL);
    if(!window) { glfwTerminate(); return EXIT_FAILURE; }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    setupBricks();
    spawnBall();
    spawnBall();
    glClearColor(.055f,.075f,.12f,1.f);
    double previous=glfwGetTime();
    double accumulator=0;
    const double fixedStep=1.0/120.0;
    while(!glfwWindowShouldClose(window)) {
        double now=glfwGetTime();
        double frame=std::min(.05,now-previous);
        previous=now;
        input(window);
        accumulator+=frame;
        while(accumulator>=fixedStep) {
            step(static_cast<float>(fixedStep));
            accumulator-=fixedStep;
        }
        int width,height;
        glfwGetFramebufferSize(window,&width,&height);
        if(height==0) { glfwPollEvents(); continue; }
        glViewport(0,0,width,height);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-1,1,-1,1,-1,1);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glClear(GL_COLOR_BUFFER_BIT);
        for(size_t i=0;i<bricks.size();++i) bricks[i].draw();
        for(size_t i=0;i<balls.size();++i) balls[i].draw();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    return EXIT_SUCCESS;
}
